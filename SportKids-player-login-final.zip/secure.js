(() => {
  const config = window.SPORTKIDS_SUPABASE;
  if (!config?.url || !config?.publishableKey || !window.supabase) return;

  const authDb = window.supabase.createClient(config.url, config.publishableKey);
  let dataDb = authDb;
  let session = null;
  let mode = null;
  let syncing = false;
  let syncTimer = null;
  const byId = id => document.getElementById(id);
  const playerEmail = login => `${login.trim().toLowerCase()}@login.sportkids.app`;
  const status = text => { const node = byId('sessionStatus'); if (node) node.textContent = text; };
  const message = (id, text) => { const node = byId(id); if (node) node.textContent = text || ''; };
  const dialog = (id, open) => byId(id)?.classList.toggle('open', open);

  function setSession(nextSession) {
    session = nextSession || null;
    dataDb = session ? window.supabase.createClient(config.url, config.publishableKey, {
      auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
      accessToken: () => Promise.resolve(session.access_token)
    }) : authDb;
  }

  function stateForCloud(player) { const state = { ...player }; delete state.cloudId; return state; }
  function hydrate(row) {
    const state = row.app_state && typeof row.app_state === 'object' ? row.app_state : {};
    return { ...state, id: state.id || `p-${row.id}`, cloudId: row.id, name: row.full_name || state.name || '', age: row.age ?? state.age ?? '', position: row.position || state.position || '', history: state.history || {}, tests: state.tests || [], challenges: state.challenges || {}, period: state.period || { month: 'Січень', week: 'Тиждень 1' }, goal: state.goal || null };
  }

  async function syncPlayers(list) {
    if (!session || mode !== 'coach' || syncing) return false;
    syncing = true;
    try {
      for (const player of list) {
        const payload = { coach_id: session.user.id, full_name: player.name || 'Новий гравець', age: player.age ? Number(player.age) : null, position: player.position || null, app_state: stateForCloud(player) };
        if (player.cloudId) {
          const { error } = await dataDb.from('player_accounts').update(payload).eq('id', player.cloudId);
          if (error) throw error;
        } else {
          const { data, error } = await dataDb.from('player_accounts').insert(payload).select('id').single();
          if (error) throw error;
          player.cloudId = data.id;
        }
      }
      localStorage.setItem('sportkids-players', JSON.stringify(list));
      status('Збережено у профілі тренера');
      return true;
    } catch (error) { status(`Помилка збереження: ${error.message}`); return false; }
    finally { syncing = false; }
  }

  async function loadCoach() {
    const { data, error } = await dataDb.from('player_accounts').select('*').eq('coach_id', session.user.id).order('created_at');
    if (error) { status(`Помилка завантаження: ${error.message}`); return; }
    mode = 'coach'; document.body.classList.remove('player-only');
    if (data.length) window.SportKidsApp.replacePlayers(data.map(hydrate), localStorage.getItem('sportkids-active'));
    else await syncPlayers(window.SportKidsApp.getPlayers());
    status('Кабінет тренера');
  }

  async function loadPlayer() {
    const { data, error } = await dataDb.from('player_accounts').select('*').eq('player_user_id', session.user.id).maybeSingle();
    if (error || !data) { status(error ? `Помилка доступу: ${error.message}` : 'Для цього логіна ще не призначено профіль гравця.'); return; }
    mode = 'player';
    window.SportKidsApp.replacePlayers([hydrate(data)], hydrate(data).id);
    window.SportKidsApp.setPlayerOnly();
    status(`Профіль гравця: ${data.full_name || data.username}`);
  }

  async function refreshSession() {
    const { data } = await authDb.auth.getSession();
    setSession(data.session);
    if (!session) { mode = null; document.body.classList.remove('player-only'); status('Увійдіть як тренер або гравець'); return; }
    if (session.user.user_metadata?.role === 'player') await loadPlayer(); else await loadCoach();
  }

  async function coachLogin(event) {
    event.preventDefault(); message('accessMessage', 'Вхід…');
    const { data, error } = await authDb.auth.signInWithPassword({ email: byId('coachEmail').value.trim(), password: byId('coachPassword').value });
    if (error) { message('accessMessage', error.message); return; }
    setSession(data.session); await loadCoach(); byId('loginButton').hidden = true; byId('logoutButton').hidden = false; dialog('accessDialog', false);
  }

  async function playerLogin(event) {
    event.preventDefault(); message('accessMessage', 'Вхід…');
    const { data, error } = await authDb.auth.signInWithPassword({ email: playerEmail(byId('playerLogin').value), password: byId('playerPassword').value });
    if (error) { message('accessMessage', 'Неправильний логін або пароль.'); return; }
    setSession(data.session); await loadPlayer(); byId('loginButton').hidden = true; byId('logoutButton').hidden = false; dialog('accessDialog', false);
  }

  async function createPlayerLogin(event) {
    event.preventDefault();
    const player = window.SportKidsApp.getPlayers().find(item => item.id === window.SportKidsApp.getActiveId());
    if (!player?.cloudId) { message('credentialsMessage', 'Спочатку збережіть профіль гравця.'); return; }
    const login = byId('newPlayerLogin').value.trim().toLowerCase();
    const password = byId('newPlayerPassword').value;
    if (!/^[a-z0-9._-]{3,30}$/.test(login)) { message('credentialsMessage', 'Логін: латинські літери, цифри, крапка, дефіс або _.'); return; }
    message('credentialsMessage', 'Створюємо доступ…');
    const isolated = window.supabase.createClient(config.url, config.publishableKey, { auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false } });
    const { data: signUp, error: signUpError } = await isolated.auth.signUp({ email: playerEmail(login), password, options: { data: { role: 'player' } } });
    if (signUpError || !signUp.user) { message('credentialsMessage', signUpError?.message || 'Не вдалося створити логін.'); return; }
    const { error } = await dataDb.from('player_accounts').update({ player_user_id: signUp.user.id, username: login }).eq('id', player.cloudId);
    if (error) { message('credentialsMessage', error.message); return; }
    player.login = login; window.SportKidsApp.getPlayers();
    message('credentialsMessage', `Готово. Логін гравця: ${login}`);
  }

  function queueSync(players) { if (mode !== 'coach') return; clearTimeout(syncTimer); syncTimer = setTimeout(() => syncPlayers(players), 600); }
  function chooseAccess(next) { document.querySelectorAll('[data-access]').forEach(button => button.classList.toggle('active', button.dataset.access === next)); byId('coachLoginForm').classList.toggle('hidden', next !== 'coach'); byId('playerLoginForm').classList.toggle('hidden', next !== 'player'); message('accessMessage', ''); }

  window.SportKidsSecure = { start: async () => {
    byId('loginButton')?.addEventListener('click', () => dialog('accessDialog', true));
    byId('logoutButton')?.addEventListener('click', () => authDb.auth.signOut());
    byId('accessClose')?.addEventListener('click', () => dialog('accessDialog', false));
    byId('credentialsClose')?.addEventListener('click', () => dialog('playerCredentialsDialog', false));
    byId('coachLoginForm')?.addEventListener('submit', coachLogin);
    byId('playerLoginForm')?.addEventListener('submit', playerLogin);
    byId('playerCredentialsForm')?.addEventListener('submit', createPlayerLogin);
    byId('createPlayerLogin')?.addEventListener('click', () => { if (mode !== 'coach') return; message('credentialsMessage', ''); dialog('playerCredentialsDialog', true); });
    document.querySelectorAll('[data-access]').forEach(button => button.addEventListener('click', () => chooseAccess(button.dataset.access)));
    await refreshSession();
    byId('loginButton').hidden = Boolean(session); byId('logoutButton').hidden = !session;
    authDb.auth.onAuthStateChange(() => { setTimeout(async () => { await refreshSession(); const loggedIn = Boolean(session); byId('loginButton').hidden = loggedIn; byId('logoutButton').hidden = !loggedIn; }, 0); });
  }, queueSync };
})();
