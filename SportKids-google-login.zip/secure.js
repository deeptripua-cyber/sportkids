(() => {
  const config = window.SPORTKIDS_SUPABASE;
  if (!config?.url || !config?.publishableKey || !window.supabase) return;

  const authDb = window.supabase.createClient(config.url, config.publishableKey);
  // This is a browser app using Supabase Auth. The authenticated client already
  // attaches the current session token to every database request.
  let dataDb = authDb;
  let session = null;
  let mode = null;
  let syncing = false;
  let syncTimer = null;
  const byId = id => document.getElementById(id);
  const playerEmail = login => `${login.trim().toLowerCase()}@login.sportkids.app`;
  const normalizeEmail = email => String(email || '').trim().toLowerCase();
  const isGoogleUser = () => session?.user?.app_metadata?.provider === 'google' || session?.user?.identities?.some(identity => identity.provider === 'google');
  const googleModeKey = userId => `sportkids-google-mode:${userId}`;
  const status = text => { const node = byId('sessionStatus'); if (node) node.textContent = text; };
  const message = (id, text) => { const node = byId(id); if (node) node.textContent = text || ''; };
  const dialog = (id, open) => byId(id)?.classList.toggle('open', open);

  function setSession(nextSession) {
    session = nextSession || null;
    dataDb = authDb;
  }

  function stateForCloud(player) { const state = { ...player }; delete state.cloudId; return state; }
  function hydrate(row) {
    const state = row.app_state && typeof row.app_state === 'object' ? row.app_state : {};
    return { ...state, id: state.id || `p-${row.id}`, cloudId: row.id, name: row.full_name || state.name || '', age: row.age ?? state.age ?? '', position: row.position || state.position || '', googleEmail: row.player_google_email || state.googleEmail || '', history: state.history || {}, tests: state.tests || [], challenges: state.challenges || {}, period: state.period || { month: 'Січень', week: 'Тиждень 1' }, goal: state.goal || null };
  }

  async function syncPlayers(list) {
    if (!session || mode !== 'coach' || syncing) return false;
    syncing = true;
    try {
      for (const player of list) {
        const payload = { coach_id: session.user.id, full_name: player.name || 'Новий гравець', age: player.age ? Number(player.age) : null, position: player.position || null, player_google_email: normalizeEmail(player.googleEmail) || null, app_state: stateForCloud(player) };
        if (player.cloudId) {
          const { data, error } = await dataDb.from('player_accounts')
            .update(payload)
            .eq('id', player.cloudId)
            .eq('coach_id', session.user.id)
            .select('id')
            .maybeSingle();
          if (error) throw error;
          // PostgREST can return no error when RLS hides an outdated id. In that
          // case create a fresh private record instead of silently losing changes.
          if (!data) player.cloudId = null;
        }
        if (!player.cloudId) {
          const { data, error } = await dataDb.from('player_accounts').insert(payload).select('id').single();
          if (error) throw error;
          player.cloudId = data.id;
        }
      }
      // A single-player save must never overwrite the coach's other local players.
      localStorage.setItem('sportkids-players', JSON.stringify(window.SportKidsApp?.getPlayers?.() || list));
      status('Збережено у профілі тренера');
      return true;
    } catch (error) { status(`Помилка збереження: ${error.message}`); return false; }
    finally { syncing = false; }
  }

  async function loadCoach() {
    const { data, error } = await dataDb.from('player_accounts').select('*').eq('coach_id', session.user.id).order('created_at');
    if (error) { status(`Помилка завантаження: ${error.message}`); return false; }
    mode = 'coach'; document.body.classList.remove('player-only');
    if (data.length) window.SportKidsApp.replacePlayers(data.map(hydrate), localStorage.getItem('sportkids-active'));
    else if (!(await syncPlayers(window.SportKidsApp.getPlayers()))) return false;
    status('Кабінет тренера');
    return true;
  }

  async function loadPlayer() {
    let { data, error } = await dataDb.from('player_accounts').select('*').eq('player_user_id', session.user.id).maybeSingle();
    // A Google player receives access only when a coach has entered the same
    // Gmail address into that player's profile. The RPC sets no other fields.
    if (!data && !error && isGoogleUser()) {
      const claimed = await dataDb.rpc('claim_google_player_profile');
      if (claimed.error) error = claimed.error;
      else if (claimed.data) ({ data, error } = await dataDb.from('player_accounts').select('*').eq('player_user_id', session.user.id).maybeSingle());
    }
    if (error || !data) {
      status(error ? `Помилка доступу: ${error.message}` : isGoogleUser() ? 'Цей Google-акаунт ще не призначено жодному профілю. Попросіть тренера вказати вашу Gmail-адресу.' : 'Для цього логіна ще не призначено профіль гравця.');
      return false;
    }
    mode = 'player';
    window.SportKidsApp.replacePlayers([hydrate(data)], hydrate(data).id);
    window.SportKidsApp.setPlayerOnly();
    status(`Профіль гравця: ${data.full_name || data.username}`);
    return true;
  }

  async function refreshSession() {
    const { data } = await authDb.auth.getSession();
    setSession(data.session);
    if (!session) { mode = null; document.body.classList.remove('player-only'); status('Демо-режим: увійдіть як тренер, щоб зберігати дані у базі'); return; }
    const pendingGoogleMode = localStorage.getItem('sportkids-google-mode-pending');
    if (pendingGoogleMode && isGoogleUser()) {
      localStorage.setItem(googleModeKey(session.user.id), pendingGoogleMode);
      localStorage.removeItem('sportkids-google-mode-pending');
    }
    const requestedGoogleMode = isGoogleUser() ? localStorage.getItem(googleModeKey(session.user.id)) : null;
    if (session.user.user_metadata?.role === 'player' || requestedGoogleMode === 'player') {
      const opened = await loadPlayer();
      if (!opened && isGoogleUser()) {
        await authDb.auth.signOut();
        chooseAccess('player');
        message('accessMessage', 'Цю Gmail ще не прив’язано до профілю. Попросіть тренера додати вашу Gmail-адресу та збережіть профіль.');
        dialog('accessDialog', true);
      }
    } else await loadCoach();
  }

  async function coachLogin(event) {
    event.preventDefault(); message('accessMessage', 'Вхід…');
    const { data, error } = await authDb.auth.signInWithPassword({ email: byId('coachEmail').value.trim(), password: byId('coachPassword').value });
    if (error) { message('accessMessage', error.message); return; }
    setSession(data.session);
    if (!(await loadCoach())) { message('accessMessage', 'Не вдалося відкрити кабінет тренера. Перевірте повідомлення у верхній частині сторінки.'); return; }
    byId('loginButton').hidden = true; byId('logoutButton').hidden = false; dialog('accessDialog', false);
  }

  async function playerLogin(event) {
    event.preventDefault(); message('accessMessage', 'Вхід…');
    const { data, error } = await authDb.auth.signInWithPassword({ email: playerEmail(byId('playerLogin').value), password: byId('playerPassword').value });
    if (error) { message('accessMessage', 'Неправильний логін або пароль.'); return; }
    setSession(data.session);
    if (!(await loadPlayer())) {
      await authDb.auth.signOut();
      message('accessMessage', 'Цей логін існує, але ще не прив’язаний до профілю. Тренер має створити доступ повторно після оновлення сайту.');
      return;
    }
    byId('loginButton').hidden = true; byId('logoutButton').hidden = false; dialog('accessDialog', false);
  }

  async function googleLogin(accessMode) {
    localStorage.setItem('sportkids-google-mode-pending', accessMode);
    message('accessMessage', 'Перенаправляємо до Google…');
    const { error } = await authDb.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${window.location.origin}${window.location.pathname}` }
    });
    if (error) {
      localStorage.removeItem('sportkids-google-mode-pending');
      message('accessMessage', `Не вдалося відкрити Google: ${error.message}`);
    }
  }

  async function createPlayerLogin(event) {
    event.preventDefault();
    const player = window.SportKidsApp.getPlayers().find(item => item.id === window.SportKidsApp.getActiveId());
    if (!session || mode !== 'coach') { message('credentialsMessage', 'Увійдіть як тренер, щоб створити доступ.'); return; }
    if (!player) { message('credentialsMessage', 'Оберіть профіль гравця.'); return; }
    const login = byId('newPlayerLogin').value.trim().toLowerCase();
    const password = byId('newPlayerPassword').value;
    if (!/^[a-z0-9._-]{3,30}$/.test(login)) { message('credentialsMessage', 'Логін: латинські літери, цифри, крапка, дефіс або _.'); return; }

    message('credentialsMessage', 'Перевіряємо профіль…');
    // Ensure the selected local profile really belongs to this trainer in Supabase.
    // This also repairs old local cloudId values left by previous versions.
    const saved = await syncPlayers([player]);
    if (!saved || !player.cloudId) {
      message('credentialsMessage', 'Не вдалося зберегти профіль гравця у базі. Увійдіть тренером ще раз і повторіть дію.');
      return;
    }
    const { data: existing, error: existingError } = await dataDb.from('player_accounts')
      .select('id, player_user_id, username')
      .eq('id', player.cloudId)
      .eq('coach_id', session.user.id)
      .maybeSingle();
    if (existingError || !existing) {
      message('credentialsMessage', existingError?.message || 'Профіль гравця не знайдено у вашому кабінеті.');
      return;
    }
    if (existing.player_user_id) {
      message('credentialsMessage', `Для цього профілю вже створено вхід${existing.username ? `: ${existing.username}` : ''}.`);
      return;
    }

    message('credentialsMessage', 'Створюємо доступ…');
    const isolated = window.supabase.createClient(config.url, config.publishableKey, { auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false } });
    const { data: signUp, error: signUpError } = await isolated.auth.signUp({ email: playerEmail(login), password, options: { data: { role: 'player' } } });
    if (signUpError || !signUp.user) {
      const text = signUpError?.message || 'Не вдалося створити логін.';
      message('credentialsMessage', /already registered/i.test(text) ? 'Такий логін уже існує. Оберіть інший або видаліть старий непідключений вхід у Supabase → Authentication → Users.' : text);
      return;
    }
    if (!signUp.session) {
      message('credentialsMessage', 'У Supabase увімкнене підтвердження email. Вимкніть Confirm email у Authentication → Providers → Email, видаліть щойно створений непідключений вхід і повторіть дію.');
      return;
    }
    const { data: linked, error } = await dataDb.from('player_accounts')
      .update({ player_user_id: signUp.user.id, username: login })
      .eq('id', player.cloudId)
      .eq('coach_id', session.user.id)
      .select('id, player_user_id, username')
      .maybeSingle();
    if (error || !linked || linked.player_user_id !== signUp.user.id) {
      message('credentialsMessage', error?.message || 'Вхід створено, але не прив’язано. Не передавайте цей пароль; повторіть створення з іншим логіном.');
      return;
    }
    player.login = login; window.SportKidsApp.getPlayers();
    message('credentialsMessage', `Готово. Логін гравця: ${login}`);
  }

  function queueSync(players) { if (mode !== 'coach') return; clearTimeout(syncTimer); syncTimer = setTimeout(() => syncPlayers(players), 600); }
  function chooseAccess(next) { document.querySelectorAll('[data-access]').forEach(button => button.classList.toggle('active', button.dataset.access === next)); byId('coachLoginForm').classList.toggle('hidden', next !== 'coach'); byId('playerLoginForm').classList.toggle('hidden', next !== 'player'); message('accessMessage', ''); }

  window.SportKidsSecure = { start: async () => {
    byId('loginButton')?.addEventListener('click', () => dialog('accessDialog', true));
    byId('logoutButton')?.addEventListener('click', () => authDb.auth.signOut());
    byId('accessClose')?.addEventListener('click', () => dialog('accessDialog', false));
    byId('credentialsClose')?.addEventListener('click', () => dialog('playerCredentialsDialog', false));
    byId('coachLoginForm')?.addEventListener('submit', coachLogin);
    byId('playerLoginForm')?.addEventListener('submit', playerLogin);
    document.querySelectorAll('[data-google-access]').forEach(button => button.addEventListener('click', () => googleLogin(button.dataset.googleAccess)));
    byId('playerCredentialsForm')?.addEventListener('submit', createPlayerLogin);
    byId('createPlayerLogin')?.addEventListener('click', () => {
      if (mode !== 'coach') {
        chooseAccess('coach');
        message('accessMessage', 'Спочатку увійдіть у кабінет тренера. Після цього профіль і вхід гравця збережуться у базі.');
        dialog('accessDialog', true);
        return;
      }
      message('credentialsMessage', '');
      dialog('playerCredentialsDialog', true);
    });
    document.querySelectorAll('[data-access]').forEach(button => button.addEventListener('click', () => chooseAccess(button.dataset.access)));
    await refreshSession();
    byId('loginButton').hidden = Boolean(session); byId('logoutButton').hidden = !session;
    authDb.auth.onAuthStateChange(() => { setTimeout(async () => { await refreshSession(); const loggedIn = Boolean(session); byId('loginButton').hidden = loggedIn; byId('logoutButton').hidden = !loggedIn; }, 0); });
  }, queueSync };
})();
